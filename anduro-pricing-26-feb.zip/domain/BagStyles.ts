export type BagStyles = 'Default' | 'Standard' | 'Step Cut';
