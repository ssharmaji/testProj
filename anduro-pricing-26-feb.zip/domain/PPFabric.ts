export type PPFabric =
  | 'SAMSA'
  | 'SASICASA'
  | 'SIMPLEX'
  | 'EMPAQUES - GENERAL'
  | 'INDIA'
  | 'ANDURO 1'
  | 'ANDURO 2';
