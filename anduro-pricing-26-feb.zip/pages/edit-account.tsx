import * as React from 'react';
import firebase from 'firebase/app';
import { useForm } from 'react-hook-form';
import { format } from 'date-fns';
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
  Button,
  ButtonGroup,
  Flex,
  Heading,
  Spinner,
} from '@chakra-ui/react';
import { useRouter } from 'next/router';
import { useCollection } from 'react-firebase-hooks/firestore';

import { useAppDispatch } from '../state/useAppDispatch';
import { clearQuoteData, setQuoteData } from '../state/quote/quote.slice';
import {
  BagSize,
  BagSizesQuoteEle,
  Closure,
  CustomerDetails,
  FabricAndLamination,
  GeneralInformation,
  Logistics,
  OuterLayer,
  Settings,
  SpecialInstructions,
} from '../components/FormSections';
import { IQuoteForm } from '../domain/IQuoteForm';
import { testFormData, TESTING } from '../utils/test.utils';
import { useSelector } from 'react-redux';
import { formStateSelector } from '../state/quote/quote.selectors';
import withAuth from '../auth/withAuth';
import { useUser } from '../auth/useUser';
import PhoneLogin from '../components/PhoneLogin/PhoneLogin';

const EditAccount = () => {
  const activeLoader = true;
  const [isSmallScreen, setIsSmallScreen] = React.useState(false);

  React.useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth <= 767);
    };

    // Initial check on component mount
    handleResize();

    // Add event listener for window resize
    window.addEventListener('resize', handleResize);

    // Remove event listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const dispatch = useAppDispatch();
  const router = useRouter();

  const { user }: { user: any } = useUser();
  const [isAdmin, setIsAdmin] = React.useState<boolean>(false);
  const [isQuoter, setIsQuoter] = React.useState<boolean>(false);
  const [canViewForm, setCanViewForm] = React.useState<boolean>(false);
  const [admins, adminsLoading, adminsError] = useCollection(
    firebase.firestore().collection('admins'),
    {}
  );
  const [quoters, quotersLoading, quotersError] = useCollection(
    firebase.firestore().collection('quoters'),
    {}
  );

  React.useEffect(() => {
    console.log(admins);
    admins &&
      admins.docs.map((doc) => {
        const adminPhone = doc.data().phone;
        if (user && user?.phone.includes(adminPhone)) {
          // //console.log('INCLUDES');

          // const newData = {
          //   // Define the data you want to add
          //   // For example:
          //   name_tmp: 'John Doe',
          //   email: 'john.doe@example.com',
          //   // Add more fields as needed
          // };

          // firebase.firestore().collection('admins').doc('IYwzhJMs3PJVCPSNeewo').update(newData)
          // .then(() => {
          //   console.log('Data added successfully.');
          // })
          // .catch(error => {
          //   console.error('Error adding data: ', error);
          // });

          setIsAdmin(true);
          return true;
        }
        return false;
      });
  }, [admins, user, setIsAdmin]);

  React.useEffect(() => {
    quoters &&
      quoters.docs.map((doc) => {
        const quoterPhone = doc.data().phone;
        if (user && user.phone.includes(quoterPhone)) {
          setIsQuoter(true);
          return true;
        }
        return false;
      });
  }, [user, quoters, setIsQuoter]);

  React.useEffect(() => {
    setCanViewForm(isAdmin || isQuoter);
    setCanViewForm(true);
  }, [isAdmin, isQuoter]);
  const formState: IQuoteForm = useSelector(formStateSelector);
  const {
    control,
    handleSubmit,
    register,
    reset,
    watch,
    formState: { errors },
    setValue,
  } = useForm<IQuoteForm>({
    defaultValues: TESTING ? testFormData : formState,
  });

  const onSubmit = (data: IQuoteForm) => {
    const {
      orderDate,
      desiredDeliveryDate,
      specialLamination,
      handle,
      moqKg,
      moqKgOtherValue,
      adLamCharge,
    } = data;

    const moqKgValue = moqKg === 'Other' ? moqKgOtherValue : moqKg;

    const quoteData = Object.assign({}, data, {
      orderDate: format(orderDate as Date, 'yyyy-MM-dd'),
      desiredDeliveryDate: format(desiredDeliveryDate as Date, 'yyyy-MM-dd'),
      handle: handle === '' ? 'No' : handle,
      finishedLength,
      adLamCharge: specialLamination === 'No' ? 0 : adLamCharge,
      moqKg: moqKgValue,
      // sleeveLength:sleeveLength,
      // sleeveLengthTest:sleeveLength
    });

    dispatch(setQuoteData(quoteData));
    //router.push('/quote');
    router.push('/quote-detail');
  };

  const onCancel = (e: React.SyntheticEvent) => {
    e.preventDefault();
    reset();
    //dispatch(clearQuoteData());
  };

  if (!user?.id) {
    return <PhoneLogin />;
  }

  return (
    <Box
      className="container-box"
      bgAttachment="fixed"
      bgImage="url('/Anduro_BOPP_weave21500SM.jpg')"
      bgPosition="center"
      bgRepeat="no-repeat"
      bgSize="cover"
      h="full"
      minH="screen"
      py={8}
    >
      <Box mx="auto" position="relative" zIndex={10}>
        {activeLoader || adminsLoading || (quotersLoading && <Spinner />)}
        {adminsError && adminsError.code !== 'permission-denied' && (
          <strong>Error: {JSON.stringify(adminsError)}</strong>
        )}
        {quotersError && quotersError.code !== 'permission-denied' && (
          <strong>Error: {JSON.stringify(quotersError)}</strong>
        )}
        {canViewForm && (
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box>
              <Accordion defaultIndex={[0, 1, 2, 3, 4, 5, 6, 7]} allowMultiple>
                <div className="container">
                  <div className="edit-account">
                    <div className="box">
                      <AccordionItem id="accountInformation">
                        <AccordionButton>
                          <Box flex="1" textAlign="left">
                            <Heading
                              as="h2"
                              py={1}
                              size="md"
                              textTransform="uppercase"
                            >
                              General Information
                            </Heading>
                          </Box>
                          <AccordionIcon />
                        </AccordionButton>
                      </AccordionItem>
                    </div>
                  </div>
                </div>
              </Accordion>
            </Box>
          </form>
        )}
      </Box>
    </Box>
  );
};

export default withAuth(EditAccount);
// export default EditAccount;
