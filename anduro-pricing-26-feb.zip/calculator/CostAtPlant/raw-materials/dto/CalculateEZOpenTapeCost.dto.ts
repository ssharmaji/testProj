export interface CalculateEZOpenTapeCostDto {
  ezOpenTape: string;
  qty: number;
  width: number;
}
