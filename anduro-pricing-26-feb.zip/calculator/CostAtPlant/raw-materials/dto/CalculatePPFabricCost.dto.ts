export interface CalculatePPFabricCostDto {
  fabricColor: string;
  fabricGSM: number;
  fabricSupplier: string;
  gusset: number;
  length: number;
  qty: number;
  width: number;
}
