export interface CalculateThreadCostDto {
  closedEnd: string;
  qty: number;
  width: number;
}
