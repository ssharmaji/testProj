export interface CalculateBagSeamResinsCostDto {
  closedEnd: string;
  length: number;
  qty: number;
  width: number;
}
