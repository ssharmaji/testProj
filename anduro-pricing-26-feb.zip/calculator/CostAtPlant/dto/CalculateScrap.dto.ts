export interface CalculateScrapDto {
  rawMaterialCost: number;
}
