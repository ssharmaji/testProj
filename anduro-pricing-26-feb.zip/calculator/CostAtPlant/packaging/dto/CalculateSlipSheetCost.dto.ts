export interface CalculateSlipSheetCostDto {
  bagsPerPallet: number;
  qty: number;
  totalPallets: number;
}