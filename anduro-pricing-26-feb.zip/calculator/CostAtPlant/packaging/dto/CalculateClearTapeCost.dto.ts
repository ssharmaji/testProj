export interface CalculateClearTapeCostDto {
  qty: number;
}
