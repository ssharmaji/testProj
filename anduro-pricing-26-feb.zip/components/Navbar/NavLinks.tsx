const NavLinks = ({ showLabel = false }) => {
  return (
    <div className="nav-links">
      <ul className="option-list">
        <li>
          <a href="#">
            <i className="fa fa-bell" aria-hidden="true"></i>{showLabel && "Notifications"}
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-cog" aria-hidden="true"></i>{showLabel && "General"}
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-light fa-user-circle-o" aria-hidden="true"></i>{showLabel && "Account"}
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-lock" aria-hidden="true"></i>{showLabel && "Privacy"}
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-ban" aria-hidden="true"></i>{showLabel && "Block"}
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-question-circle" aria-hidden="true"></i>{showLabel && "Help"}
          </a>
        </li>
      </ul>
    </div>
  );
};

export default NavLinks;
