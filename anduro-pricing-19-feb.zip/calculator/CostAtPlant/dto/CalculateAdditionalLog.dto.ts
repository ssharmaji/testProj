export interface CalculateAdditionalLogDto {
  logisticsPrice: number;
  qty: number;
}
