export interface CalculatePackagingCostDto {
  qty: number;
  totalPallets: number;
}
