export interface CalculateStaplesCostDto {
  qty: number;
  
}