export interface CalculateLaminationResinsCostDto {
  extrudateGSM: number;
  gusset: number;
  length: number;
  qty: number;
  width: number;
}
