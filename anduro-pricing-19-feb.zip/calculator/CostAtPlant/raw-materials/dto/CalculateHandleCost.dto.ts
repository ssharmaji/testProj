import { YesOrNo } from '../../../../domain/YesOrNo';

export interface CalculateHandleCostDto {
  handle: YesOrNo;
}
