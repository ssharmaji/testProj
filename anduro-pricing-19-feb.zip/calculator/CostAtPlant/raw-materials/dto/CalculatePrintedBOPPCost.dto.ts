export interface CalculatePrintedBOPPCostDto {
  length: number;
  gusset: number;
  layerMaterial: string;
  matteFinish: boolean;
  printedGSM: number;
  qty: number;
  width: number;
}
