export interface Calculate25PPFabricTapeCostDto {
  closedEnd: string;
  ezOpenTape: string;
  qty: number;
  width: number;
}
