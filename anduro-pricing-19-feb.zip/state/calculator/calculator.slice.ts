import { createSlice } from "@reduxjs/toolkit";

export const quoteSlice = createSlice({
  name: 'calculator',
  initialState: {},
  reducers: {}
})