module.exports = {
  future: {
    webpack5: true,
  },
};
