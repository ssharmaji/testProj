import * as React from 'react';
import withAuth from '../auth/withAuth';
import { Image } from '@chakra-ui/react';

const Settings = () => {
  return (
    <div className="setting-page">
      <div className="head-section">
        <h2>Settings</h2>
      </div>

      <div className="banner-section">
        <Image src="/user-icon.png" alt="user Icon" />
      </div>
      <div className="detail-box">
        <div className="left-box">
          <h2>John Doe</h2>
          <p>San Francisco, CA</p>
        </div>
        <button type="button">EDIT</button>
      </div>
      <ul className="option-list">
        <li>
          <a href="#">
            <i className="fa fa-bell" aria-hidden="true"></i>Notifications
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-cog" aria-hidden="true"></i>General
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-user" aria-hidden="true"></i>Account
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-lock" aria-hidden="true"></i>Privacy
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-ban" aria-hidden="true"></i>Block
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-question-circle" aria-hidden="true"></i>Help
          </a>
        </li>
      </ul>
    </div>
  );
};

export default withAuth(Settings);
// export default Home;
