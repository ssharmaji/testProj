import * as React from 'react';
import FormLayout from '../components/from';
const Form = () => {
  return <FormLayout />;
};

export default Form;
