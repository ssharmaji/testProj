import { Image, Flex } from '@chakra-ui/react';
import * as React from 'react';

const Navbar = () => {
  return (
    <Flex
      as="nav"
      bg="white"
      h="64px"
      px={8}
      w="100%"
      align="center"
      justify={{ base: 'center', md: 'between' }}
      pos="fixed"
      zIndex={50}
    >
      <Image
        src="/Anduro-logo-horz-1.png"
        alt="Anduro Manufacturing"
        h="100%"
      />
    </Flex>
  );
};

export default Navbar;
