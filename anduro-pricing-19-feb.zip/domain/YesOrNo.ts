export type YesOrNo = 'Yes' | 'No' | '';
