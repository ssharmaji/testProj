export type StickerOrHotMelt =
  | 'No'
  | 'Small (2.5" x 1.5")'
  | 'Med (4" x 4")'
  | 'Large (8" x 8")'
  | 'Hot Melt';
