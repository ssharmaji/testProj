export type SelectValue<T> = Record<'value' | 'display', T>;
